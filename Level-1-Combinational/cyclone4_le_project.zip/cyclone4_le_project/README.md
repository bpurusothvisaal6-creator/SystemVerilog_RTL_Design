# Cyclone IV Logic Element — Educational Structural RTL Model

This project is a **synthesizable, structural Verilog-2001 model** of the
Altera/Intel **Cyclone IV Logic Element (LE)**, built to be architecturally
faithful to the block diagram published in the Cyclone IV Handbook (Figure
5.60, "Cyclone IV Logic Element (LE)").

It is an **original, from-scratch RTL implementation** written to reproduce
the LE's *documented functional architecture and block-level structure* —
not Intel's internal transistor-level or SRAM-cell-level design, which is
proprietary and is not used or referenced here. It is intended for
FPGA-architecture education and for RTL-hierarchy/schematic exploration in
tools like Vivado.

## 1. Folder Structure

```
cyclone4_le_project/
├── README.md
├── rtl/
│   ├── lut4.v                       4-input LUT
│   ├── carry_chain.v                Dedicated carry chain
│   ├── reg_feedback_mux.v           Register feedback MUX (into LUT data3)
│   ├── sync_load_clear_logic.v      Synchronous load/clear combinational logic
│   ├── async_clear_logic.v          Asynchronous clear logic
│   ├── clk_clkena_select.v          Clock & clock-enable select
│   ├── programmable_register.v      The register itself (sequential only)
│   ├── register_bypass_mux.v        Register bypass MUX
│   ├── register_chain_routing.v     Register chain output (cascade to next LE)
│   ├── row_routing_mux.v            Row routing output MUX
│   ├── column_routing_mux.v         Column routing output MUX
│   ├── direct_link_routing_mux.v    Direct-link routing output MUX
│   ├── local_routing_mux.v          Local routing output MUX
│   └── cyclone4_le_top.v            Top-level LE — structural instantiation only
├── sim/
│   └── tb_cyclone4_le.v             Self-checking testbench
└── scripts/
    └── create_project.tcl           Vivado project creation script
```

## 2. Module Hierarchy

```
cyclone4_le_top
├── reg_feedback_mux         (u_reg_feedback_mux)
├── lut4                     (u_lut4)
├── carry_chain              (u_carry_chain)
├── sync_load_clear_logic    (u_sync_load_clear_logic)
├── async_clear_logic        (u_async_clear_logic)
├── clk_clkena_select        (u_clk_clkena_select)
├── programmable_register    (u_programmable_register)
├── register_bypass_mux      (u_register_bypass_mux)
├── register_chain_routing   (u_register_chain_routing)
├── row_routing_mux          (u_row_routing_mux)
├── column_routing_mux       (u_column_routing_mux)
├── direct_link_routing_mux  (u_direct_link_routing_mux)
└── local_routing_mux        (u_local_routing_mux)
```

Every major block from the diagram is a **separate module and a separate
file**. `cyclone4_le_top.v` contains no combinational or sequential logic of
its own — it only declares wires and instantiates/connects submodules, so
the RTL hierarchy (and the resulting Vivado elaborated schematic) mirrors
the diagram's block structure directly.

## 3. Connection Explanation (mapped to the diagram)

| Diagram element | RTL signal / module |
|---|---|
| data1–data4 | `data1`–`data4` top-level inputs |
| Register feedback loop into data3 | `reg_feedback_mux` output feeds `lut4.in[2]` |
| Look-Up Table (LUT) | `lut4` |
| Carry Chain | `carry_chain`; `carry_in`/`carry_out` are LE carry-in/out |
| Register chain routing from previous LE | `reg_chain_in` → `sync_load_clear_logic` (selectable via `reg_chain_sel`) |
| LAB-wide synchronous load | `lab_sync_load` → `sync_load_clear_logic` |
| LAB-wide synchronous clear | `lab_sync_clear` → `sync_load_clear_logic` |
| Synchronous Load and Clear Logic | `sync_load_clear_logic` (combinational; drives register `D`) |
| labclr1 / labclr2 / DEV_CLRn | `labclr1`, `labclr2`, `dev_clrn` → `async_clear_logic` |
| Asynchronous Clear Logic | `async_clear_logic` (drives register `ACLRN`) |
| labclk1 / labclk2 / labclkena1 / labclkena2 | `clk_clkena_select` |
| Clock & Clock Enable Select | `clk_clkena_select` (drives register `CLK`/`ENA`) |
| Programmable register | `programmable_register` (D/CLK/ENA/ACLRN → Q, sequential only) |
| Register bypass MUX ("O  O") | `register_bypass_mux` |
| Row, column, and direct link routing (x2 taps) | `row_routing_mux`, `column_routing_mux`, `direct_link_routing_mux` |
| Local routing | `local_routing_mux` |
| Register chain output | `register_chain_routing` |
| LE carry-out | `carry_chain.carry_out` → top-level `carry_out` |

## 4. LUT Behavior

`lut4` is a fully programmable 4-input LUT driven by a 16-bit
`lut_mask` configuration vector:

```verilog
assign lut_out = lut_mask[in];   // in = {data4, data3, data2, data1}
```

No Boolean function is hard-coded; changing `lut_mask` reprograms the LUT
exactly like loading a real device's configuration bitstream.

## 5. Simulation Instructions

### Using Vivado XSIM
```tcl
cd cyclone4_le_project
vivado -mode batch -source scripts/create_project.tcl
launch_simulation
run all
```

### Using an open-source simulator (Icarus Verilog)
```bash
cd cyclone4_le_project
iverilog -g2001 -o sim/tb_cyclone4_le.vvp rtl/*.v sim/tb_cyclone4_le.v
vvp sim/tb_cyclone4_le.vvp
# optional waveform:
gtkwave tb_cyclone4_le.vcd
```

The testbench (`sim/tb_cyclone4_le.v`) exercises:
1. Combinational LUT-only mode (register bypassed) — LUT programmed as a
   4-input AND gate.
2. Registered mode with synchronous load and synchronous clear.
3. Asynchronous clear.
4. Register feedback (LUT input driven by the register's own output).
5. Carry chain propagation.

## 6. Vivado Synthesis / RTL Schematic Instructions

1. `vivado -mode batch -source scripts/create_project.tcl` (or open Vivado
   GUI and run the same script from the Tcl console).
2. In the Flow Navigator, click **Run Synthesis** (or `synth_design -rtl`
   for a pre-synthesis elaborated view).
3. Open **RTL Analysis → Open Elaborated Design → Schematic**.

### Expected RTL Schematic

Because `cyclone4_le_top` purely instantiates submodules with no shared/
flattened logic, the elaborated schematic will show one clearly bounded
block per submodule, connected by the signals listed in the table above:
a LUT block feeding a carry-chain block, feeding a small mux-based
combinational cloud (sync load/clear logic) into a single D flip-flop
(the programmable register, with its `CLR` pin fed by the async-clear
block and `CE` pin fed by the clock-enable-select block), followed by a
bypass mux and four independent output muxes fanning out to
`row_out`/`column_out`/`direct_link_out`/`local_out`, plus the dedicated
`reg_chain_out` tap straight off the register. This directly mirrors the
layout of the published architecture diagram.

## 7. Configuration ("Control") Signals Summary

These correspond to SRAM configuration bits that would normally be set by
the Quartus fitter/bitstream in a real device; here they are exposed as
plain inputs so the LE's behavior can be configured/tested directly:

| Signal | Function |
|---|---|
| `lut_mask[15:0]` | LUT truth table |
| `reg_fb_sel` | Route register Q back into LUT data3 input |
| `reg_chain_sel` | Use register-chain cascade input instead of LUT/carry result |
| `sload_en`, `sclr_en` | Enable synchronous load / synchronous clear |
| `aclr_en`, `aclr_sel` | Enable async clear, select labclr1/labclr2 |
| `clk_sel`, `ena_sel` | Select labclk1/labclk2, labclkena1/labclkena2 |
| `bypass_sel` | 1 = combinational (register bypass), 0 = registered |
| `row_sel`, `column_sel`, `direct_link_sel`, `local_sel` | Per-tap: combinational vs. registered output |

## 8. Notes / Scope

- Verilog-2001 only, no SystemVerilog, no vendor primitives/IP, no black
  boxes.
- The carry chain here models a representative propagate/generate carry
  structure (`carry_out = lut_out ? carry_in : 0`, `sumout = lut_out ^
  carry_in`) — a simplified but structurally-visible stand-in for the
  Cyclone IV's dedicated fast-carry hardware, which is not itself
  documented at the gate level in public material.
- This is an educational/architectural model, not a bit-accurate
  reproduction of Intel's proprietary Cyclone IV silicon implementation.
