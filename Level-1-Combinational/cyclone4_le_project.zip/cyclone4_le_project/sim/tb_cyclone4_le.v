// =============================================================================
// Testbench   : tb_cyclone4_le
// Description : Exercises the cyclone4_le_top model through several
//               representative configurations:
//                 1. Combinational LUT-only mode (register bypassed)
//                 2. Registered mode with synchronous load/clear
//                 3. Asynchronous clear
//                 4. Register feedback (toggle flip-flop built from LUT)
//                 5. Carry chain propagation across two chained LEs
// =============================================================================
`timescale 1ns/1ps

module tb_cyclone4_le;

    reg         data1, data2, data3, data4;
    reg  [15:0] lut_mask;
    reg         carry_in;
    wire        carry_out;
    reg         reg_fb_sel;
    reg         reg_chain_in, reg_chain_sel;
    reg         lab_sync_load, lab_sync_clear, sload_en, sclr_en;
    reg         labclr1, labclr2, dev_clrn, aclr_sel, aclr_en;
    reg         labclk1, labclk2, labclkena1, labclkena2, clk_sel, ena_sel;
    reg         bypass_sel;
    reg         row_sel, column_sel, direct_link_sel, local_sel;
    wire        row_out, column_out, direct_link_out, local_out, reg_chain_out;

    // ---------------------------------------------------------------
    // DUT instantiation
    // ---------------------------------------------------------------
    cyclone4_le_top dut (
        .data1           (data1),
        .data2           (data2),
        .data3           (data3),
        .data4           (data4),
        .lut_mask        (lut_mask),
        .carry_in        (carry_in),
        .carry_out       (carry_out),
        .reg_fb_sel      (reg_fb_sel),
        .reg_chain_in    (reg_chain_in),
        .reg_chain_sel   (reg_chain_sel),
        .lab_sync_load   (lab_sync_load),
        .lab_sync_clear  (lab_sync_clear),
        .sload_en        (sload_en),
        .sclr_en         (sclr_en),
        .labclr1         (labclr1),
        .labclr2         (labclr2),
        .dev_clrn        (dev_clrn),
        .aclr_sel        (aclr_sel),
        .aclr_en         (aclr_en),
        .labclk1         (labclk1),
        .labclk2         (labclk2),
        .labclkena1      (labclkena1),
        .labclkena2      (labclkena2),
        .clk_sel         (clk_sel),
        .ena_sel         (ena_sel),
        .bypass_sel      (bypass_sel),
        .row_sel         (row_sel),
        .column_sel      (column_sel),
        .direct_link_sel (direct_link_sel),
        .local_sel       (local_sel),
        .row_out         (row_out),
        .column_out      (column_out),
        .direct_link_out (direct_link_out),
        .local_out       (local_out),
        .reg_chain_out   (reg_chain_out)
    );

    // ---------------------------------------------------------------
    // Clock generation: labclk1 = 10ns period
    // ---------------------------------------------------------------
    initial labclk1 = 1'b0;
    always #5 labclk1 = ~labclk1;

    initial labclk2 = 1'b0; // unused clock source, tied low for this test

    // ---------------------------------------------------------------
    // Stimulus
    // ---------------------------------------------------------------
    initial begin
        $dumpfile("tb_cyclone4_le.vcd");
        $dumpvars(0, tb_cyclone4_le);

        // ---- Default / safe initial values ----
        data1 = 0; data2 = 0; data3 = 0; data4 = 0;
        carry_in = 0;
        reg_fb_sel = 0;
        reg_chain_in = 0; reg_chain_sel = 0;
        lab_sync_load = 0; lab_sync_clear = 0; sload_en = 0; sclr_en = 0;
        labclr1 = 0; labclr2 = 0; dev_clrn = 1; aclr_sel = 0; aclr_en = 0;
        labclkena1 = 1; labclkena2 = 1; clk_sel = 0; ena_sel = 0;
        bypass_sel = 1; // start in combinational (bypass) mode
        row_sel = 1; column_sel = 1; direct_link_sel = 1; local_sel = 1;

        // Program LUT as a 4-input AND gate: lut_mask[15]=1, all else 0
        lut_mask = 16'h8000;

        #12;
        $display("---- TEST 1: Combinational LUT-only mode (4-input AND) ----");
        data1 = 1; data2 = 1; data3 = 1; data4 = 1; #10;
        $display("t=%0t data=%b%b%b%b row_out=%b (expect 1)", $time, data4,data3,data2,data1, row_out);
        data1 = 0; #10;
        $display("t=%0t data=%b%b%b%b row_out=%b (expect 0)", $time, data4,data3,data2,data1, row_out);

        // ---- TEST 2: Registered mode with synchronous load/clear ----
        $display("---- TEST 2: Registered mode, synchronous load/clear ----");
        bypass_sel = 0;         // route registered output
        sload_en = 1; sclr_en = 1;
        data1 = 1; data2 = 1; data3 = 1; data4 = 1; // LUT drives 1
        lab_sync_load = 0; lab_sync_clear = 0;
        @(posedge labclk1); #1;
        $display("t=%0t after normal clock, row_out=%b", $time, row_out);

        lab_sync_clear = 1;
        @(posedge labclk1); #1;
        $display("t=%0t after sync clear, row_out=%b (expect 0)", $time, row_out);
        lab_sync_clear = 0;

        lab_sync_load = 1;
        @(posedge labclk1); #1;
        $display("t=%0t after sync load, row_out=%b (expect 1)", $time, row_out);
        lab_sync_load = 0;

        // ---- TEST 3: Asynchronous clear ----
        $display("---- TEST 3: Asynchronous clear ----");
        aclr_en = 1; aclr_sel = 0;
        labclr1 = 1; #3;
        $display("t=%0t after async clear assert, row_out=%b (expect 0)", $time, row_out);
        labclr1 = 0;

        // ---- TEST 4: Register feedback (toggle flip-flop) ----
        $display("---- TEST 4: Register feedback toggle flip-flop ----");
        reg_fb_sel = 1;          // route reg_q back into LUT data3 input
        lut_mask   = 16'h0FF0;   // arbitrary function of feedback + inputs
        data1 = 1; data2 = 1; data4 = 0;
        repeat (4) begin
            @(posedge labclk1); #1;
            $display("t=%0t toggle test, row_out=%b", $time, row_out);
        end

        // ---- TEST 5: Carry chain propagation ----
        $display("---- TEST 5: Carry chain propagation ----");
        reg_fb_sel = 0; bypass_sel = 1;
        lut_mask = 16'hFFFF; // LUT always outputs 1 -> carry passes through
        data1 = 1; data2 = 1; data3 = 1; data4 = 1;
        carry_in = 1; #10;
        $display("t=%0t carry_in=%b carry_out=%b (expect 1)", $time, carry_in, carry_out);
        carry_in = 0; #10;
        $display("t=%0t carry_in=%b carry_out=%b (expect 0)", $time, carry_in, carry_out);

        #20;
        $display("---- Testbench complete ----");
        $finish;
    end

endmodule
