// =============================================================================
// Module      : reg_feedback_mux
// Description : Register Feedback Multiplexer.
//               As shown in the architecture diagram, the LUT can receive
//               feedback directly from the programmable register's own
//               output, allowing the LE to be configured, for example, as
//               a self-contained state element (T flip-flop, toggle
//               counter bit, etc.) without needing external routing.
//
//               This mux sits on the data3 input path into the LUT and
//               selects between the "normal" data3 routing input and the
//               register's own Q output fed back internally.
//
// Ports:
//   data3_in        : normal data3 input from general routing
//   reg_feedback_in : feedback from the programmable register output (Q)
//   sel             : configuration bit; 1 = select feedback, 0 = data3
//   data3_out       : resulting signal driven into the LUT's data3 input
// =============================================================================
module reg_feedback_mux (
    input  wire data3_in,
    input  wire reg_feedback_in,
    input  wire sel,
    output wire data3_out
);

    assign data3_out = sel ? reg_feedback_in : data3_in;

endmodule
