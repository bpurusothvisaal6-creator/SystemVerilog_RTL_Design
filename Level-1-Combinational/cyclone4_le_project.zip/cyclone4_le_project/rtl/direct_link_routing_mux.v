// =============================================================================
// Module      : direct_link_routing_mux
// Description : Direct Link Routing output multiplexer. Direct link
//               interconnect allows an LE to drive its neighboring LE
//               directly without using general row/column routing,
//               matching the architecture diagram's dedicated direct-link
//               routing tap.
//
// Ports:
//   combout_in       : LE combinational output (post register-bypass mux)
//   regout_in        : LE registered output
//   sel              : configuration bit; 1 = combinational, 0 = registered
//   direct_link_out  : output driven onto the direct-link interconnect
// =============================================================================
module direct_link_routing_mux (
    input  wire combout_in,
    input  wire regout_in,
    input  wire sel,
    output wire direct_link_out
);

    assign direct_link_out = sel ? combout_in : regout_in;

endmodule
