// =============================================================================
// Module      : programmable_register
// Description : Programmable Register.
//               This module contains ONLY sequential logic - all decision
//               logic (synchronous load/clear next-state computation,
//               asynchronous clear generation, clock/clock-enable
//               selection) is deliberately implemented OUTSIDE this module
//               in dedicated blocks, exactly as required by the
//               architecture diagram. This keeps the register's role
//               architecturally "pure": D in, Q out, gated by clock,
//               clock-enable, and asynchronous clear only.
//
// Ports:
//   clk    : register clock (from clk_clkena_select)
//   ena    : clock enable (from clk_clkena_select)
//   aclrn  : asynchronous clear, active low (from async_clear_logic)
//   d      : next-state data input (from sync_load_clear_logic)
//   q      : registered output
// =============================================================================
module programmable_register (
    input  wire clk,
    input  wire ena,
    input  wire aclrn,
    input  wire d,
    output reg  q
);

    always @(posedge clk or negedge aclrn) begin
        if (!aclrn)
            q <= 1'b0;
        else if (ena)
            q <= d;
        // else: clock-enable low -> register holds its current value
    end

endmodule
