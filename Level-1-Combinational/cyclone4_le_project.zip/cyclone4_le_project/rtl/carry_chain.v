// =============================================================================
// Module      : carry_chain
// Description : Dedicated carry-chain logic for the Cyclone IV Logic Element.
//               This block sits directly beside the LUT (as shown in the
//               architecture diagram) and is architecturally distinct from
//               general routing - it uses a dedicated, fast, chip-internal
//               carry path from one LE to the next.
//
//               carry_out is passed vertically to the carry_in of the next
//               LE in the LAB, allowing fast ripple-carry arithmetic (e.g.
//               adders/counters) without using general routing resources.
//
//               sumout represents the LE's combinational data output after
//               the carry chain has been factored in (i.e. what would
//               normally be called "combout" upstream of the register).
//
// Ports:
//   lut_out   : combinational output of the 4-input LUT
//   carry_in  : carry-in from the previous LE in the chain (LE carry-in)
//   carry_out : carry-out to the next LE in the chain (LE carry-out)
//   sumout    : combinational data output feeding the rest of the LE
// =============================================================================
module carry_chain (
    input  wire lut_out,
    input  wire carry_in,
    output wire carry_out,
    output wire sumout
);

    // Propagate/generate style dedicated carry logic:
    //   - When lut_out = 1, the carry is propagated through unchanged.
    //   - When lut_out = 0, the carry chain generates a 0.
    // This models the fast dedicated carry propagate/generate structure
    // used by LUT-based FPGA carry chains, kept fully visible as its own
    // architectural block (not folded into the LUT or register).
    assign carry_out = lut_out ? carry_in : 1'b0;

    // Arithmetic sum output (e.g. for a full-adder style LE configuration):
    // XOR of the LUT result and the incoming carry.
    assign sumout = lut_out ^ carry_in;

endmodule
