// =============================================================================
// Module      : register_chain_routing
// Description : Register Chain Routing (output side).
//               Provides the dedicated "Register chain output" path shown
//               in the architecture diagram, allowing this LE's registered
//               output to cascade directly into the next LE's
//               sync_load_clear_logic block (see reg_chain_in /
//               reg_chain_sel in that module) without consuming general
//               routing resources. This dedicated shift-register style
//               cascade is commonly used to build fast shift registers.
//
// Ports:
//   regout_in     : LE registered output (programmable_register.q)
//   reg_chain_out : dedicated register-chain output to the next LE
// =============================================================================
module register_chain_routing (
    input  wire regout_in,
    output wire reg_chain_out
);

    assign reg_chain_out = regout_in;

endmodule
