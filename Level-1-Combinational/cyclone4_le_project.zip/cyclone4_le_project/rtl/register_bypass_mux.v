// =============================================================================
// Module      : register_bypass_mux
// Description : Register Bypass Multiplexer (the "O  O" mux pair shown
//               directly beside the programmable register in the
//               architecture diagram).
//
//               When register bypass is selected, the LE's combinational
//               result (straight from the LUT/Carry-Chain block) is routed
//               directly to the output routing muxes, skipping the
//               register entirely - this is how combinational-only LEs
//               are implemented on the real device. Otherwise, the
//               registered output (Q) is used.
//
// Ports:
//   combout_in  : combinational data output (from carry_chain.sumout)
//   regout_in   : registered output (from programmable_register.q)
//   bypass_sel  : configuration bit; 1 = bypass register (combinational),
//                 0 = use registered output
//   le_out      : resulting LE output driven into the output routing muxes
// =============================================================================
module register_bypass_mux (
    input  wire combout_in,
    input  wire regout_in,
    input  wire bypass_sel,
    output wire le_out
);

    assign le_out = bypass_sel ? combout_in : regout_in;

endmodule
