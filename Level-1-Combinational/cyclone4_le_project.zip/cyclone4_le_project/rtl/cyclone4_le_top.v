// =============================================================================
// Module      : cyclone4_le_top
// Description : Top-level Cyclone IV Logic Element (LE).
//               Structural RTL model, architecturally faithful to the
//               published Cyclone IV LE diagram (Altera Cyclone IV
//               Handbook, Figure "Cyclone IV Logic Element (LE)").
//
//               This module does NOT contain behavioral logic of its own;
//               it purely instantiates the architectural sub-blocks and
//               wires them together exactly as shown in the diagram:
//
//                 Cyclone4_LE
//                 |
//                 +-- LUT (lut4)
//                 +-- Register Feedback MUX (reg_feedback_mux)
//                 +-- Carry Chain (carry_chain)
//                 +-- Sync Load/Clear Logic (sync_load_clear_logic)
//                 +-- Async Clear Logic (async_clear_logic)
//                 +-- Clock & Clock Enable Select (clk_clkena_select)
//                 +-- Programmable Register (programmable_register)
//                 +-- Register Bypass MUX (register_bypass_mux)
//                 +-- Register Chain Routing (register_chain_routing)
//                 +-- Row Routing MUX (row_routing_mux)
//                 +-- Column Routing MUX (column_routing_mux)
//                 +-- Direct Link Routing MUX (direct_link_routing_mux)
//                 +-- Local Routing MUX (local_routing_mux)
//
//               See README.md for full port descriptions, connection
//               explanation and expected RTL schematic structure.
// =============================================================================
module cyclone4_le_top (
    // ---------------- LUT data inputs ----------------
    input  wire        data1,
    input  wire        data2,
    input  wire        data3,
    input  wire        data4,
    input  wire [15:0] lut_mask,

    // ---------------- Carry chain ----------------
    input  wire        carry_in,
    output wire        carry_out,

    // ---------------- Register feedback control ----------------
    input  wire        reg_fb_sel,

    // ---------------- Register chain routing (from previous LE) ----------------
    input  wire        reg_chain_in,
    input  wire        reg_chain_sel,

    // ---------------- LAB-wide synchronous load/clear ----------------
    input  wire        lab_sync_load,
    input  wire        lab_sync_clear,
    input  wire        sload_en,
    input  wire        sclr_en,

    // ---------------- Asynchronous clear ----------------
    input  wire        labclr1,
    input  wire        labclr2,
    input  wire        dev_clrn,
    input  wire        aclr_sel,
    input  wire        aclr_en,

    // ---------------- Clock / clock-enable select ----------------
    input  wire        labclk1,
    input  wire        labclk2,
    input  wire        labclkena1,
    input  wire        labclkena2,
    input  wire        clk_sel,
    input  wire        ena_sel,

    // ---------------- Register bypass control ----------------
    input  wire        bypass_sel,

    // ---------------- Output routing select controls ----------------
    input  wire        row_sel,
    input  wire        column_sel,
    input  wire        direct_link_sel,
    input  wire        local_sel,

    // ---------------- Output routing ----------------
    output wire        row_out,
    output wire        column_out,
    output wire        direct_link_out,
    output wire        local_out,
    output wire        reg_chain_out
);

    // -------------------------------------------------------------------
    // Internal interconnect
    // -------------------------------------------------------------------
    wire        data3_muxed;     // data3 after register-feedback mux
    wire        lut_out;         // raw LUT output
    wire        combout;         // LUT/Carry-Chain combinational data (sumout)
    wire        reg_d;           // next-state value into the register
    wire        reg_q;           // registered output
    wire        reg_aclrn;       // asynchronous clear into the register
    wire        reg_clk;         // selected clock into the register
    wire        reg_ena;         // selected clock enable into the register
    wire        le_out;          // LE output after register-bypass mux

    // -------------------------------------------------------------------
    // Register Feedback Multiplexer
    // Allows the register's own output to feed back into the LUT's data3
    // input, exactly as shown in the diagram.
    // -------------------------------------------------------------------
    reg_feedback_mux u_reg_feedback_mux (
        .data3_in        (data3),
        .reg_feedback_in (reg_q),
        .sel             (reg_fb_sel),
        .data3_out       (data3_muxed)
    );

    // -------------------------------------------------------------------
    // 4-input Look-Up Table
    // -------------------------------------------------------------------
    lut4 u_lut4 (
        .in       ({data4, data3_muxed, data2, data1}),
        .lut_mask (lut_mask),
        .lut_out  (lut_out)
    );

    // -------------------------------------------------------------------
    // Carry Chain
    // -------------------------------------------------------------------
    carry_chain u_carry_chain (
        .lut_out   (lut_out),
        .carry_in  (carry_in),
        .carry_out (carry_out),
        .sumout    (combout)
    );

    // -------------------------------------------------------------------
    // Synchronous Load and Clear Logic
    // -------------------------------------------------------------------
    sync_load_clear_logic u_sync_load_clear_logic (
        .combout_in     (combout),
        .reg_chain_in   (reg_chain_in),
        .lab_sync_load  (lab_sync_load),
        .lab_sync_clear (lab_sync_clear),
        .sload_en       (sload_en),
        .sclr_en        (sclr_en),
        .reg_chain_sel  (reg_chain_sel),
        .reg_d          (reg_d)
    );

    // -------------------------------------------------------------------
    // Asynchronous Clear Logic
    // -------------------------------------------------------------------
    async_clear_logic u_async_clear_logic (
        .labclr1   (labclr1),
        .labclr2   (labclr2),
        .dev_clrn  (dev_clrn),
        .aclr_sel  (aclr_sel),
        .aclr_en   (aclr_en),
        .reg_aclrn (reg_aclrn)
    );

    // -------------------------------------------------------------------
    // Clock & Clock Enable Select
    // -------------------------------------------------------------------
    clk_clkena_select u_clk_clkena_select (
        .labclk1    (labclk1),
        .labclk2    (labclk2),
        .labclkena1 (labclkena1),
        .labclkena2 (labclkena2),
        .clk_sel    (clk_sel),
        .ena_sel    (ena_sel),
        .reg_clk    (reg_clk),
        .reg_ena    (reg_ena)
    );

    // -------------------------------------------------------------------
    // Programmable Register (purely sequential)
    // -------------------------------------------------------------------
    programmable_register u_programmable_register (
        .clk   (reg_clk),
        .ena   (reg_ena),
        .aclrn (reg_aclrn),
        .d     (reg_d),
        .q     (reg_q)
    );

    // -------------------------------------------------------------------
    // Register Bypass Multiplexer
    // -------------------------------------------------------------------
    register_bypass_mux u_register_bypass_mux (
        .combout_in (combout),
        .regout_in  (reg_q),
        .bypass_sel (bypass_sel),
        .le_out     (le_out)
    );

    // -------------------------------------------------------------------
    // Register Chain Routing (dedicated cascade output to next LE)
    // -------------------------------------------------------------------
    register_chain_routing u_register_chain_routing (
        .regout_in     (reg_q),
        .reg_chain_out (reg_chain_out)
    );

    // -------------------------------------------------------------------
    // Independent Output Routing Multiplexers
    // -------------------------------------------------------------------
    row_routing_mux u_row_routing_mux (
        .combout_in (le_out),
        .regout_in  (reg_q),
        .sel        (row_sel),
        .row_out    (row_out)
    );

    column_routing_mux u_column_routing_mux (
        .combout_in (le_out),
        .regout_in  (reg_q),
        .sel        (column_sel),
        .column_out (column_out)
    );

    direct_link_routing_mux u_direct_link_routing_mux (
        .combout_in      (le_out),
        .regout_in       (reg_q),
        .sel             (direct_link_sel),
        .direct_link_out (direct_link_out)
    );

    local_routing_mux u_local_routing_mux (
        .combout_in (le_out),
        .regout_in  (reg_q),
        .sel        (local_sel),
        .local_out  (local_out)
    );

endmodule
