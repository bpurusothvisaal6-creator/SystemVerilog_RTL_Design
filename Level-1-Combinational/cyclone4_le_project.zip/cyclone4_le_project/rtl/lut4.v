// =============================================================================
// Module      : lut4
// Description : Configurable 4-input Look-Up Table (LUT).
//               Behaves exactly like a real programmable LUT: the 4 select
//               inputs {in[3:0]} index directly into a 16-bit configuration
//               mask (the "LUT mask"), which represents the truth table
//               programmed into the LUT during device configuration.
//
//               No Boolean equations are hard-coded here - the function
//               performed by the LUT is entirely determined by lut_mask,
//               exactly as in the real Cyclone IV LE.
//
// Ports:
//   in        : 4-bit input vector -> in[0]=data1, in[1]=data2,
//                                      in[2]=data3 (post feedback mux),
//                                      in[3]=data4
//   lut_mask  : 16-bit LUT configuration RAM contents (SRAM configuration
//               bits programmed at bitstream load time)
//   lut_out   : combinational LUT output
// =============================================================================
module lut4 (
    input  wire [3:0]  in,
    input  wire [15:0] lut_mask,
    output wire         lut_out
);

    // Variable bit-select indexing: lut_mask[in] selects exactly one bit of
    // the 16-bit mask based on the 4-bit input vector. This is fully
    // synthesizable and infers standard LUT logic.
    assign lut_out = lut_mask[in];

endmodule
