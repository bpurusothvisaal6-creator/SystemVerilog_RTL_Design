// =============================================================================
// Module      : async_clear_logic
// Description : Asynchronous Clear Logic.
//               Generates the active-low asynchronous clear (ACLRN) signal
//               that drives the programmable register's async reset pin
//               directly, independent of the clock, exactly as shown in
//               the architecture diagram.
//
//               Two LAB-wide asynchronous clear sources (labclr1, labclr2)
//               are available per LE, plus a chip-wide asynchronous reset
//               (DEV_CLRn) that unconditionally resets every register on
//               the device regardless of how the LE is configured.
//
// Ports:
//   labclr1   : LAB-wide asynchronous clear source 1 (active high request)
//   labclr2   : LAB-wide asynchronous clear source 2 (active high request)
//   dev_clrn  : chip-wide asynchronous reset, active LOW (DEV_CLRn)
//   aclr_sel  : configuration bit - 0 selects labclr1, 1 selects labclr2
//   aclr_en   : configuration bit - enables the LAB-wide async clear source
//               for this LE (if disabled, only DEV_CLRn can reset the reg)
//   reg_aclrn : resulting active-low asynchronous clear driven to the
//               programmable register
// =============================================================================
module async_clear_logic (
    input  wire labclr1,
    input  wire labclr2,
    input  wire dev_clrn,
    input  wire aclr_sel,
    input  wire aclr_en,
    output wire reg_aclrn
);

    wire sel_labclr;

    // Select between the two LAB-wide asynchronous clear sources.
    assign sel_labclr = aclr_sel ? labclr2 : labclr1;

    // Final asynchronous clear (active low):
    //   - Chip-wide DEV_CLRn always participates (global override reset).
    //   - LAB-wide clear only participates if this LE is configured to use
    //     asynchronous clear (aclr_en).
    assign reg_aclrn = dev_clrn & ~(aclr_en & sel_labclr);

endmodule
