// =============================================================================
// Module      : clk_clkena_select
// Description : Clock & Clock Enable Select.
//               Each LE can select from two LAB-wide clocks and two
//               LAB-wide clock-enable signals, as shown in the
//               architecture diagram directly below the Asynchronous
//               Clear Logic block.
//
// Ports:
//   labclk1     : LAB-wide clock source 1
//   labclk2     : LAB-wide clock source 2
//   labclkena1  : LAB-wide clock-enable source 1
//   labclkena2  : LAB-wide clock-enable source 2
//   clk_sel     : configuration bit - 0 selects labclk1, 1 selects labclk2
//   ena_sel     : configuration bit - 0 selects labclkena1, 1 selects
//                 labclkena2
//   reg_clk     : resulting clock driven to the programmable register
//   reg_ena     : resulting clock-enable driven to the programmable register
// =============================================================================
module clk_clkena_select (
    input  wire labclk1,
    input  wire labclk2,
    input  wire labclkena1,
    input  wire labclkena2,
    input  wire clk_sel,
    input  wire ena_sel,
    output wire reg_clk,
    output wire reg_ena
);

    assign reg_clk = clk_sel ? labclk2 : labclk1;
    assign reg_ena = ena_sel ? labclkena2 : labclkena1;

endmodule
