// =============================================================================
// Module      : local_routing_mux
// Description : Local Routing output multiplexer. Local interconnect
//               distributes the LE's output to other LEs within the same
//               LAB, matching the architecture diagram's dedicated "Local
//               routing" tap, separate from row/column/direct-link.
//
// Ports:
//   combout_in : LE combinational output (post register-bypass mux)
//   regout_in  : LE registered output
//   sel        : configuration bit; 1 = combinational, 0 = registered
//   local_out  : output driven onto local routing
// =============================================================================
module local_routing_mux (
    input  wire combout_in,
    input  wire regout_in,
    input  wire sel,
    output wire local_out
);

    assign local_out = sel ? combout_in : regout_in;

endmodule
