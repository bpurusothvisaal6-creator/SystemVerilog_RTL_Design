// =============================================================================
// Module      : row_routing_mux
// Description : Row Routing output multiplexer. One of several independent
//               output taps shown in the architecture diagram ("Row,
//               column, and direct link routing"). Kept as its own
//               dedicated module so the routing architecture remains
//               visible in the RTL hierarchy/schematic rather than being
//               collapsed into a single shared mux.
//
// Ports:
//   combout_in : LE combinational output (post register-bypass mux)
//   regout_in  : LE registered output
//   sel        : configuration bit; 1 = drive combinational path onto the
//                row routing resource, 0 = drive registered path
//   row_out    : output driven onto row routing
// =============================================================================
module row_routing_mux (
    input  wire combout_in,
    input  wire regout_in,
    input  wire sel,
    output wire row_out
);

    assign row_out = sel ? combout_in : regout_in;

endmodule
