// =============================================================================
// Module      : column_routing_mux
// Description : Column Routing output multiplexer. Independent from the
//               row/direct-link/local routing muxes, matching the
//               architecture diagram's separate "Row, column, and direct
//               link routing" output taps.
//
// Ports:
//   combout_in  : LE combinational output (post register-bypass mux)
//   regout_in   : LE registered output
//   sel         : configuration bit; 1 = combinational path, 0 = registered
//   column_out  : output driven onto column routing
// =============================================================================
module column_routing_mux (
    input  wire combout_in,
    input  wire regout_in,
    input  wire sel,
    output wire column_out
);

    assign column_out = sel ? combout_in : regout_in;

endmodule
