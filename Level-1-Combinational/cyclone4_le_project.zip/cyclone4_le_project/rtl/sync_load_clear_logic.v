// =============================================================================
// Module      : sync_load_clear_logic
// Description : Synchronous Load and Clear Logic.
//               This is purely COMBINATIONAL logic that computes the
//               next-state value (D) to be presented to the programmable
//               register on the next clock edge. It sits between the
//               LUT/Carry-Chain block and the register, exactly as shown
//               in the architecture diagram.
//
//               It also selects between the LE's own combinational result
//               (from the LUT/Carry Chain) and the register-chain input
//               coming from the previous LE (register cascade), as the
//               diagram shows a "Register chain routing from previous LE"
//               feeding into this same block.
//
//               The register itself contains NO decision logic - all
//               synchronous load/clear decisions are made here, and the
//               register simply samples reg_d on the clock edge.
//
// Ports:
//   combout_in     : combinational data from the LUT/Carry Chain block
//   reg_chain_in   : register-chain routing input from the previous LE
//   lab_sync_load  : LAB-wide synchronous load control signal
//   lab_sync_clear : LAB-wide synchronous clear control signal
//   sload_en       : configuration bit - enables synchronous load feature
//   sclr_en        : configuration bit - enables synchronous clear feature
//   reg_chain_sel  : configuration bit - selects register-chain input
//                     instead of the LUT/Carry-Chain combinational output
//   reg_d          : resulting next-state value driven to the register D
// =============================================================================
module sync_load_clear_logic (
    input  wire combout_in,
    input  wire reg_chain_in,
    input  wire lab_sync_load,
    input  wire lab_sync_clear,
    input  wire sload_en,
    input  wire sclr_en,
    input  wire reg_chain_sel,
    output wire reg_d
);

    wire data_sel;
    wire after_load;

    // Choose data source: LE's own combinational output, or the register
    // chain cascade input from the previous LE.
    assign data_sel = reg_chain_sel ? reg_chain_in : combout_in;

    // Synchronous load: when enabled and asserted, forces next-state to 1.
    assign after_load = (sload_en & lab_sync_load) ? 1'b1 : data_sel;

    // Synchronous clear: when enabled and asserted, forces next-state to 0.
    // Synchronous clear takes priority over synchronous load, matching
    // typical LAB-wide control precedence.
    assign reg_d = (sclr_en & lab_sync_clear) ? 1'b0 : after_load;

endmodule
