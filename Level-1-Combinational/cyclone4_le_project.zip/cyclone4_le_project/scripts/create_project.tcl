# =============================================================================
# create_project.tcl
# Creates a Vivado project for the Cyclone IV LE educational RTL model and
# adds all design + simulation sources.
#
# Usage (from Vivado Tcl console, or vivado -mode batch -source create_project.tcl):
#   cd <path to cyclone4_le_project>
#   vivado -mode batch -source scripts/create_project.tcl
#
# Adjust the -part argument below to any target part/board you have
# installed; this project does not use any vendor primitives, so it will
# synthesize on essentially any Xilinx part.
# =============================================================================

set proj_name "cyclone4_le_project"
set proj_dir  "./vivado_project"
set part_name "xc7a35tcpg236-1"    ;# example: Artix-7 (Basys3). Change as needed.

create_project $proj_name $proj_dir -part $part_name -force

# ---------------------------------------------------------------------------
# Add RTL sources
# ---------------------------------------------------------------------------
add_files -norecurse {
    rtl/lut4.v
    rtl/carry_chain.v
    rtl/reg_feedback_mux.v
    rtl/sync_load_clear_logic.v
    rtl/async_clear_logic.v
    rtl/clk_clkena_select.v
    rtl/programmable_register.v
    rtl/register_bypass_mux.v
    rtl/row_routing_mux.v
    rtl/column_routing_mux.v
    rtl/direct_link_routing_mux.v
    rtl/local_routing_mux.v
    rtl/register_chain_routing.v
    rtl/cyclone4_le_top.v
}

# ---------------------------------------------------------------------------
# Add simulation sources
# ---------------------------------------------------------------------------
add_files -fileset sim_1 -norecurse {
    sim/tb_cyclone4_le.v
}
set_property top tb_cyclone4_le [get_filesets sim_1]

# ---------------------------------------------------------------------------
# Set the top module for synthesis/implementation
# ---------------------------------------------------------------------------
set_property top cyclone4_le_top [current_fileset]

update_compile_order -fileset sources_1
update_compile_order -fileset sim_1

puts "Project '$proj_name' created in $proj_dir"
puts "Run 'launch_simulation' for behavioral simulation."
puts "Run 'synth_design' or use Flow Navigator -> Run Synthesis for RTL analysis."
